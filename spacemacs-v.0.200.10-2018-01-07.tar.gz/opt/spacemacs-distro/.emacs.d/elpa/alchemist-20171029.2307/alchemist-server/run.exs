Code.require_file "lib/server.exs", __DIR__

Alchemist.Server.start([System.argv])
